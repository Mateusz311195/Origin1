/*
Zajecia piatek 10:15
Mateusz Deja 311195
Krzysztof Korkuc 311317
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "header.h"

#define BUFSIZE 8192
#define MAXLINII 1000
#define MAXSLOW 100

/* Przyjmujemy nastepujace zalozenia:
- prototyp funkcji zawsze znajduje sie przed definicja
- w programie nie wystepuje wiecej niz 20 roznych funkcji
- dlugosc linii nie przekracza 8192 znakow
- funkcje wykluczone z analizy znajduja sie w analizator_s.c w tabeli funkcje (jest ich 9)
- otwarcie nawiasu klamrowego definicji funkcji wystepuje w tej samej linii co nazwa funkcji
- w komentarzu nie wystepuje cudzyslow
- wszystkie funkcje znajduja sie w calosci (prototyp, definicja, wywolanie) w jednym aktualnie analizowanym pliku
*/

int main(int argc, char *argv[])
{
	int i;
    StackElement_type *top;
    top=NULL;

    for(i=1;i <= argc-1; i++)
        analizator_skladni(argv[i]);

	return 0;
}
